insert into todo(ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE)
values(1001,'Faiyaz','Get AWS Certified',CURRENT_DATE(),false);

insert into todo(ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE)
values(1002,'Faiyaz','Get GCP Certified',CURRENT_DATE(),false);

insert into todo(ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE)
values(1003,'Faiyaz','Get SPRINGBOOT Certified',CURRENT_DATE(),false);

insert into todo(ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE)
values(1004,'Faiyaz','LEARN FULL STACK',CURRENT_DATE(),false);