package com.webapp.springboot.MyFirstWebApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
